<?php return array (
  'boda' => 'App\\Http\\Livewire\\Boda',
);